function a() {
	console.log( 'result of a()' );
}

function b() {
	console.log( 'result of b()' );
}

function c() {
	console.log( 'result of c()' );
}

// call in sequence
a();
console.log('a() is done!');

b();
console.log('b() is done!');



c();
console.log('c() is done!');